// //const http = require("http");
// //const routes = require('./routes');
// const path = require("path");
// const express = require("express");
// const bodyParser = require("body-parser");
// const expressHbs = require("express-handlebars");
// const errorController = require("./controllers/error");
// //const db = require('./util/database');
// const sequelize = require("./util/database");
// const Product = require("./models/product");
// const User = require("./models/user");
// const Cart = require("./models/cart");
// const CartItem = require("./models/cart-item");
// const Order = require("./models/order");
// const OrderItem = require("./models/order-item");
// const mongoConnect = require("./util/database").mongoConnect;

// const app = express();

// // app.engine(
// //   "hbs",
// //   expressHbs({
// //     layoutDir: "views/layouts/",
// //     defaultLayout: "main-layout",
// //     extname: "hbs",
// //   })
// // );
// //app.set("view engine", "hbs");

// // app.set('view engine', 'pug');

// app.set("view engine", "ejs");
// app.set("views", "views");

// const adminRoutes = require("./routes/admin");
// const shopRoutes = require("./routes/shop");

// // db.execute('SELECT * FROM products').then(result => {
// //     console.log(result);
// // }).catch(err => {
// //     console.log(err);
// // });

// app.use(bodyParser.urlencoded({ extended: false }));
// app.use(express.static(path.join(__dirname, "public")));
// app.use((req, res, next) => {
//   User.findById("62b47650812af58208418e06")
//     .then((user) => {
//       req.user = new User(user.name, user.email, user.cart, user._id);
//       next();
//     })
//     .catch((err) => console.log(err));
// });

// app.use("/admin", adminRoutes);
// app.use(shopRoutes);

// app.use(errorController.get404);
// // const server = http.createServer(app);
// // server.listen(3000);

// // //Sequelize
// // Product.belongsTo(User, { constraints: true, onDelete: "CASCADE" });
// // User.hasMany(Product);
// // User.hasOne(Cart);
// // Cart.belongsTo(User);

// // //Many to Many
// // Cart.belongsToMany(Product, { through: CartItem });
// // Product.belongsToMany(Cart, { through: CartItem });

// // Order.belongsTo(User);
// // User.hasMany(Order);
// // Order.belongsToMany(Product, { through: OrderItem });
// // Product.belongsToMany(Order, { through: OrderItem });

// // sequelize
// //   //.sync({force: true})
// //   .sync()
// //   .then((result) => {
// //     return User.findByPk(1);
// //     //console.log(result);
// //   })
// //   .then((user) => {
// //     if (!user) {
// //       return User.create({ name: "Max", email: "test@test.com" });
// //     }
// //     return Promise.resolve(user);
// //   })
// //   .then((user) => {
// //     return user.createCart();
// //   })
// //   .then(app.listen(3000))
// //   .catch((err) => console.log(err));

// mongoConnect(() => {
//   app.listen(3000);
// });


const path = require("path");

const express = require("express");
const bodyParser = require("body-parser");

const errorController = require("./controllers/error");
const mongoConnect = require("./util/database").mongoConnect;
const User = require("./models/user");

const app = express();

app.set("view engine", "ejs");
app.set("views", "views");

const adminRoutes = require("./routes/admin");
const shopRoutes = require("./routes/shop");

app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, "public")));

app.use((req, res, next) => {
  User.findById("62b47650812af58208418e06")
    .then((currentUser) => {
      req.user = new User(
        currentUser.name,
        currentUser.email,
        currentUser.cart,
        currentUser._id
      );
      next();
    })
    .catch((err) => console.log(err));
});

app.use("/admin", adminRoutes);
app.use(shopRoutes);

app.use(errorController.get404);

mongoConnect(() => {
  app.listen(3000);
});