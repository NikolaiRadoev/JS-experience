const { buildSchema } = require('graphql');

module.exports = buildSchema(`
    type User{
        _id: ID!
        email: String!
        password: String!
        username: String!
    }

    type AuthData {
        token: String!
        userId: String!
    }

    input UserInputData {
        email: String!
        password: String!
        username: String!
    }

    type RootQuery {
        login(email: String!, password: String!): AuthData!
    }

    type RootMutation {
        signup(userInput: UserInputData): User!
        editUser(id: ID!, userInput: UserInputData): User!
        deleteUser(id: ID!): Boolean!
    }

    schema {
        query: RootQuery
        mutation: RootMutation
    }
`);