function requestHandler(req, res) {
  const url = req.url;
  const method = req.method;
  let users = ["User 1", "User 2"];
  if (url === "/") {
    res.write(
      '<html> <head> <title> Greeting </title> </head> <body> <p> Hello </p> <form action="/create-user" method="POST"><input type="text" name="username"><button type="submit">Create user</button></form> </body> </html>'
    );
    return res.end();
  }
  if (url === "/users") {
    res.write("<html> <head> <title> Users </title> </head> <body> <ul>");
    users.forEach((user) => {
      res.write(`<li> ${user} </li>`);
    });
    res.write("</ul> </body> </html>");
    return res.end();
  }
  if (url === "/create-user" && method === "POST") {
    const body = [];
    req.on("data", (chunk) => {
      body.push(chunk);
    });
    return req.on("end", () => {
      const parsedBody = Buffer.concat(body).toString();
      const username = parsedBody.split("=")[1];
      console.log(username);
      res.statusCode = 302;
      res.setHeader("Location", "/");
      return res.end();
    });
  }
}

module.exports = requestHandler;
