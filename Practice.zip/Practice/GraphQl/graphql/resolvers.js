const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/user");

module.exports = {
  signup: async function ({ userInput }, req) {
    const hashedPw = await bcrypt.hash(userInput.password, 12);
    const user = new User({
      email: userInput.email,
      password: hashedPw,
      username: userInput.username,
    });
    const createdUser = await user.save();
    return { ...createdUser._doc, _id: "" + createdUser._id };
  },
  login: async function ({ email, password }) {
    const user = await User.findOne({ email: email });
    if (!user) {
      const error = new Error("User not found");
      error.code = 401;
      throw error;
    }
    const isEqual = await bcrypt.compare(password, user.password);
    if (!isEqual) {
      const error = new Error("Password is incorrect");
      error.code = 401;
      throw error;
    }
    const token = jwt.sign(
      {
        userId: "" + user._id,
        email: user.email,
      },
      "somesupersecretsecret",
      { expiresIn: "9h" }
    );
    return { token: token, userId: "" + user._id };
  },
  editUser: async function ({ id, userInput }, req) {
    // console.log(req.isAuth);
    if (!req.isAuth) {
      const error = new Error("Not authenticated!");
      error.code = 401;
      throw error;
    }
    const user = await User.findById(id);
    if (!user) {
      const error = new Error("User not found");
      error.code = 404;
      throw error;
    }
    user.email = userInput.email;
    user.password = userInput.password;
    user.username = userInput.username;
    const updatedUser = await user.save();
    return {
      ...updatedUser._doc,
      _id: "" + updatedUser._id,
    };
  },
  deleteUser: async function ({ id }, req) {
    // if (!req.isAuth) {
    //   const error = new Error("Not authenticated!");
    //   error.code = 401;
    //   throw error;
    // }
    const user = await User.findById(id);
    if (!user) {
      const error = new Error("User not found");
      error.code = 404;
      throw error;
    }
    await User.findByIdAndRemove(id);
    return true;
  },
};
